#version 150

uniform sampler2D DiffuseSampler;

// Normalised radius at which the vignette STARTS (fully clear inside this)
uniform float InnerRadius;
// Normalised radius at which the vignette is at full INTENSITY
uniform float OuterRadius;
// How dark the outermost edge becomes (0.0 = no effect, 1.0 = pitch black)
uniform float Intensity;
// width/height — corrects the circle into an oval on wider screens
uniform float AspectRatio;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

void main() {
    vec4 color = texture(DiffuseSampler, texCoord);

    // Offset UV so (0,0) is the screen centre
    vec2 uv = texCoord - 0.5;

    // Correct horizontal stretch so the clear zone stays round/oval
    uv.x *= AspectRatio;

    // Euclidean distance from the centre
    float dist = length(uv);

    // 0.0 inside InnerRadius → 1.0 at OuterRadius and beyond
    // smoothstep gives a soft feathered edge instead of a hard cutoff
    float vignette = smoothstep(InnerRadius, OuterRadius, dist);

    // Mix original colour toward black at the edges
    color.rgb = mix(color.rgb, vec3(0.0), vignette * Intensity);

    fragColor = color;
}
