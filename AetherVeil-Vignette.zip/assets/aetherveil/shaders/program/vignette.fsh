#version 150

uniform sampler2D DiffuseSampler;

uniform float InnerRadius;
uniform float OuterRadius;
uniform float Intensity;
uniform float AspectRatio;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec4 color = texture(DiffuseSampler, texCoord);

    // Centre UV so (0,0) = screen centre
    vec2 uv = texCoord - vec2(0.5);

    // Stretch X to compensate for widescreen — keeps the clear zone oval/round
    uv.x *= AspectRatio;

    float dist = length(uv);

    // 0.0 inside InnerRadius, smoothly rises to 1.0 at OuterRadius
    float vignette = smoothstep(InnerRadius, OuterRadius, dist);

    // Darken towards black at the edges
    color.rgb = mix(color.rgb, vec3(0.0), vignette * Intensity);

    fragColor = color;
}
